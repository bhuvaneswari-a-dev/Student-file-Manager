import re

FILE_NAME = "students.txt"


def validate_email(email):
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return re.match(pattern, email)


def add_student():
    try:
        name = input("Enter student name: ")
        roll_no = input("Enter roll number: ")
        email = input("Enter email: ")

        if not validate_email(email):
            raise ValueError("Invalid email format!")

        with open(FILE_NAME, "a") as file:
            file.write(f"{roll_no},{name},{email}\n")

        print("Student added successfully!")

    except ValueError as e:
        print("Error:", e)
    except Exception as e:
        print("Something went wrong:", e)


def read_students():
    try:
        with open(FILE_NAME, "r") as file:
            data = file.readlines()

        if not data:
            print("No student records found.")
            return

        print("\nStudent Records:")
        for record in data:
            roll_no, name, email = record.strip().split(",")
            print("Roll No:", roll_no)
            print("Name:", name)
            print("Email:", email)
            print("-------------------")

    except FileNotFoundError:
        print("No student file found.")


while True:
    print("\n===== Student Record Manager =====")
    print("1. Add Student")
    print("2. Read Student Data")
    print("3. Exit")

    try:
        choice = int(input("Enter your choice: "))

        if choice == 1:
            add_student()
        elif choice == 2:
            read_students()
        elif choice == 3:
            print("Program exited.")
            break
        else:
            print("Invalid choice! Enter 1, 2 or 3.")

    except ValueError:
        print("Please enter a number.")
