# Student Record Manager

A simple Python project to manage student records.

## Features
- Add Student
- Validate Email using Regex
- Save Student Data to File
- Read Student Data
- Handle Invalid Input using Exceptions

## Technologies Used
- Python
- Regular Expressions
- File Handling
- Exception Handling

## How to Run

```bash
python student_record_manager.py
```
